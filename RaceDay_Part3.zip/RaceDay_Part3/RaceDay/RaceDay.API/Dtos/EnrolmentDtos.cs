using System.ComponentModel.DataAnnotations;

namespace RaceDay.API.Dtos;

public record EnrolmentDto(int EnrolmentId, int ParticipantId, string ParticipantName, string ParticipantEmail,
    int CategoryId, string CategoryName, int EventId, string EventName, DateTime EnrolmentDate, string Status,
    DateOnly? EventDate = null);

public class EnrolmentStatusDto
{
    [Required, RegularExpression("^(Confirmed|Pending|Cancelled)$")] public string Status { get; set; } = "Confirmed";
}
