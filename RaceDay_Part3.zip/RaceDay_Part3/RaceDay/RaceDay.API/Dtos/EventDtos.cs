using System.ComponentModel.DataAnnotations;

namespace RaceDay.API.Dtos;

public class EventWriteDto
{
    [Required, StringLength(150)] public string EventName { get; set; } = string.Empty;
    [StringLength(1000)] public string? Description { get; set; }
    public DateOnly EventDate { get; set; }
    public TimeOnly? StartTime { get; set; }
    [Required, StringLength(200)] public string Location { get; set; } = string.Empty;
    [Url, StringLength(255)] public string? RouteMapUrl { get; set; }
    [Required, StringLength(50)] public string EventType { get; set; } = "Road Run";
    [Range(typeof(decimal), "0.01", "999.99")] public decimal? DistanceKm { get; set; }
}
public record EventSummaryDto(int EventId, string EventName, string? Description, DateOnly EventDate,
    TimeOnly? StartTime, string Location, string? RouteMapUrl, int OrganiserId, string? OrganisationName,
    string EventType = "Road Run", decimal? DistanceKm = null, string? BannerImageUrl = null);
public record EventDetailDto(int EventId, string EventName, string? Description, DateOnly EventDate,
    TimeOnly? StartTime, string Location, string? RouteMapUrl, int OrganiserId, string? OrganisationName,
    IReadOnlyList<CategoryDto> Categories, string EventType = "Road Run", decimal? DistanceKm = null,
    string? BannerImageUrl = null);
public record OrganiserEventDto(int EventId, string EventName, DateOnly EventDate, TimeOnly? StartTime,
    string Location, string EventType, decimal? DistanceKm, string? BannerImageUrl, int CategoryCount,
    int TotalEnrolments);
