using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace RaceDay.API.Services;

public class BlobStorageService : IBlobStorageService
{
    private static readonly Dictionary<string, string> Extensions = new()
    {
        ["image/jpeg"] = ".jpg",
        ["image/png"] = ".png",
        ["image/webp"] = ".webp"
    };

    private readonly IConfiguration _configuration;
    private readonly ILogger<BlobStorageService> _logger;
    private readonly SemaphoreSlim _initLock = new(1, 1);
    private BlobContainerClient? _container;

    public BlobStorageService(IConfiguration configuration, ILogger<BlobStorageService> logger)
    {
        _configuration = configuration;
        _logger = logger;
    }

    private string ContainerName => _configuration["AzureBlob:ContainerName"] is { Length: > 0 } name ? name : "raceday-images";

    public async Task<string> UploadImageAsync(Stream content, string contentType, string folder,
        CancellationToken cancellationToken = default)
    {
        if (!Extensions.TryGetValue(contentType, out var extension))
            throw new ArgumentException("Unsupported image type.", nameof(contentType));

        var container = await GetContainerAsync(cancellationToken);
        var blobName = $"{folder.Trim('/')}/{Guid.NewGuid():N}{extension}";
        var blob = container.GetBlobClient(blobName);
        await blob.UploadAsync(content, new BlobUploadOptions
        {
            HttpHeaders = new BlobHttpHeaders { ContentType = contentType, CacheControl = "public, max-age=31536000" }
        }, cancellationToken);
        return BuildPublicUrl(blob.Uri, blobName);
    }

    public async Task DeleteAsync(string? url, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(url)) return;
        try
        {
            var marker = $"/{ContainerName}/";
            var index = url.IndexOf(marker, StringComparison.Ordinal);
            if (index < 0) return;
            var blobName = Uri.UnescapeDataString(url[(index + marker.Length)..]);
            var container = await GetContainerAsync(cancellationToken);
            await container.DeleteBlobIfExistsAsync(blobName, cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Could not delete old blob {Url}", url);
        }
    }

    private string BuildPublicUrl(Uri blobUri, string blobName)
    {
        // PublicBaseUrl lets local emulators (Azurite in Docker) return a browser-reachable address.
        var publicBase = _configuration["AzureBlob:PublicBaseUrl"];
        if (string.IsNullOrWhiteSpace(publicBase)) return blobUri.ToString();
        return $"{publicBase.TrimEnd('/')}/{ContainerName}/{blobName}";
    }

    private async Task<BlobContainerClient> GetContainerAsync(CancellationToken cancellationToken)
    {
        if (_container is not null) return _container;
        await _initLock.WaitAsync(cancellationToken);
        try
        {
            if (_container is not null) return _container;

            var connectionString = _configuration["AzureBlob:ConnectionString"];
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new BlobStorageUnavailableException("Azure Blob Storage is not configured.");

            var container = new BlobServiceClient(connectionString).GetBlobContainerClient(ContainerName);
            try
            {
                await container.CreateIfNotExistsAsync(PublicAccessType.Blob, cancellationToken: cancellationToken);
            }
            catch (RequestFailedException ex) when (ex.ErrorCode == "PublicAccessNotPermitted")
            {
                _logger.LogWarning("Public blob access is disabled on the storage account; images will not be publicly viewable.");
                await container.CreateIfNotExistsAsync(cancellationToken: cancellationToken);
            }
            catch (RequestFailedException ex)
            {
                _logger.LogError(ex, "Could not reach Azure Blob Storage.");
                throw new BlobStorageUnavailableException("Azure Blob Storage is unavailable.");
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                _logger.LogError(ex, "Could not reach Azure Blob Storage.");
                throw new BlobStorageUnavailableException("Azure Blob Storage is unavailable.");
            }

            _container = container;
            return _container;
        }
        finally
        {
            _initLock.Release();
        }
    }
}
