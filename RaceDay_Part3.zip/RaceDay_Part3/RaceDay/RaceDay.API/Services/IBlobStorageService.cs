namespace RaceDay.API.Services;

public interface IBlobStorageService
{
    /// <summary>Uploads an image to Azure Blob Storage and returns its public URL.</summary>
    /// <param name="folder">Virtual folder inside the container, e.g. "banners" or "profiles".</param>
    Task<string> UploadImageAsync(Stream content, string contentType, string folder, CancellationToken cancellationToken = default);

    /// <summary>Best-effort removal of a previously uploaded image. Never throws.</summary>
    Task DeleteAsync(string? url, CancellationToken cancellationToken = default);
}

public class BlobStorageUnavailableException(string message) : Exception(message);
