using System.Security.Claims;
using Azure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Services;

namespace RaceDay.API.Controllers;

/// <summary>
/// Image uploads. The MVC front end never talks to Azure directly: it posts the file here
/// and this API stores it in Azure Blob Storage.
/// </summary>
[ApiController]
public class ImagesController(RaceDayDbContext db, IBlobStorageService blobs) : ControllerBase
{
    private const long MaxBytes = 5 * 1024 * 1024;
    private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpPost("api/events/{id:int}/banner")]
    [Authorize(Roles = "Organiser")]
    [RequestSizeLimit(MaxBytes + 1024 * 1024)]
    public async Task<IActionResult> UploadBanner(int id, IFormFile? file, CancellationToken ct)
    {
        var item = await db.Events.Include(e => e.Organiser).SingleOrDefaultAsync(e => e.EventId == id, ct);
        if (item is null) return NotFound();
        if (item.Organiser.UserId != CurrentUserId) return Forbid();

        var (contentType, error) = await ValidateAsync(file, ct);
        if (error is not null) return BadRequest(new { message = error });

        var upload = await StoreAsync(file!, contentType!, "banners", ct);
        if (upload.Failure is not null) return upload.Failure;

        var oldUrl = item.BannerImageUrl;
        item.BannerImageUrl = upload.Url;
        await db.SaveChangesAsync(ct);
        await blobs.DeleteAsync(oldUrl, ct);
        return Ok(new { bannerImageUrl = item.BannerImageUrl });
    }

    [HttpPost("api/users/me/profile-picture")]
    [Authorize]
    [RequestSizeLimit(MaxBytes + 1024 * 1024)]
    public async Task<IActionResult> UploadProfilePicture(IFormFile? file, CancellationToken ct)
    {
        var user = await db.Users.SingleOrDefaultAsync(u => u.UserId == CurrentUserId, ct);
        if (user is null) return NotFound();

        var (contentType, error) = await ValidateAsync(file, ct);
        if (error is not null) return BadRequest(new { message = error });

        var upload = await StoreAsync(file!, contentType!, "profiles", ct);
        if (upload.Failure is not null) return upload.Failure;

        var oldUrl = user.ProfilePictureUrl;
        user.ProfilePictureUrl = upload.Url;
        await db.SaveChangesAsync(ct);
        await blobs.DeleteAsync(oldUrl, ct);
        return Ok(new { profilePictureUrl = user.ProfilePictureUrl });
    }

    private async Task<(string? Url, IActionResult? Failure)> StoreAsync(IFormFile file, string contentType,
        string folder, CancellationToken ct)
    {
        try
        {
            await using var stream = file.OpenReadStream();
            var url = await blobs.UploadImageAsync(stream, contentType, folder, ct);
            return (url, null);
        }
        catch (BlobStorageUnavailableException)
        {
            return (null, StatusCode(StatusCodes.Status503ServiceUnavailable,
                new { message = "Image storage is currently unavailable. Please try again later." }));
        }
        catch (RequestFailedException)
        {
            return (null, StatusCode(StatusCodes.Status502BadGateway,
                new { message = "The image could not be stored. Please try again." }));
        }
    }

    /// <summary>Checks size and the real file signature (not just the client-supplied content type).</summary>
    private static async Task<(string? ContentType, string? Error)> ValidateAsync(IFormFile? file, CancellationToken ct)
    {
        if (file is null || file.Length == 0) return (null, "Please choose an image file to upload.");
        if (file.Length > MaxBytes) return (null, "The image must be 5 MB or smaller.");

        var header = new byte[12];
        await using (var stream = file.OpenReadStream())
        {
            var read = 0;
            while (read < header.Length)
            {
                var n = await stream.ReadAsync(header.AsMemory(read, header.Length - read), ct);
                if (n == 0) break;
                read += n;
            }
            if (read < header.Length) return (null, "That file is not a valid image.");
        }

        var detected = DetectImageType(header);
        return detected is null ? (null, "Only JPG, PNG or WEBP images are allowed.") : (detected, null);
    }

    private static string? DetectImageType(byte[] h)
    {
        if (h[0] == 0xFF && h[1] == 0xD8 && h[2] == 0xFF) return "image/jpeg";
        if (h[0] == 0x89 && h[1] == 0x50 && h[2] == 0x4E && h[3] == 0x47) return "image/png";
        if (h[0] == 0x52 && h[1] == 0x49 && h[2] == 0x46 && h[3] == 0x46 &&
            h[8] == 0x57 && h[9] == 0x45 && h[10] == 0x42 && h[11] == 0x50) return "image/webp";
        return null;
    }
}
