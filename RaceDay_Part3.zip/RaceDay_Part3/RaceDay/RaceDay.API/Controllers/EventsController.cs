using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Dtos;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers;

[ApiController]
[Route("api/events")]
public class EventsController(RaceDayDbContext db) : ControllerBase
{
    private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet]
    public async Task<IActionResult> GetEvents([FromQuery] DateOnly? from, [FromQuery] string? location,
        CancellationToken ct, [FromQuery] string? eventType = null)
    {
        var query = db.Events.Include(e => e.Organiser).ThenInclude(o => o.User)
            .Where(e => e.EventDate >= DateOnly.FromDateTime(DateTime.Today));
        if (from.HasValue) query = query.Where(e => e.EventDate >= from.Value);
        if (!string.IsNullOrWhiteSpace(location)) query = query.Where(e => e.Location.Contains(location));
        if (!string.IsNullOrWhiteSpace(eventType)) query = query.Where(e => e.EventType == eventType);
        var events = await query.OrderBy(e => e.EventDate)
            .Select(e => new EventSummaryDto(e.EventId, e.EventName, e.Description, e.EventDate, e.StartTime,
                e.Location, e.RouteMapUrl, e.OrganiserId, e.Organiser.OrganisationName,
                e.EventType, e.DistanceKm, e.BannerImageUrl)).ToListAsync(ct);
        return Ok(events);
    }

    /// <summary>All events created by the logged-in Organiser (past and upcoming) with enrolment totals.</summary>
    [HttpGet("mine")]
    [Authorize(Roles = "Organiser")]
    public async Task<IActionResult> GetMine(CancellationToken ct)
    {
        var userId = CurrentUserId;
        var events = await db.Events.Where(e => e.Organiser.UserId == userId)
            .OrderBy(e => e.EventDate)
            .Select(e => new OrganiserEventDto(e.EventId, e.EventName, e.EventDate, e.StartTime, e.Location,
                e.EventType, e.DistanceKm, e.BannerImageUrl, e.Categories.Count(),
                db.Enrolments.Count(x => x.Category.EventId == e.EventId && x.Status != "Cancelled")))
            .ToListAsync(ct);
        return Ok(events);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetEvent(int id, CancellationToken ct)
    {
        var item = await db.Events.Include(e => e.Organiser).ThenInclude(o => o.User)
            .Include(e => e.Categories).ThenInclude(c => c.Enrolments)
            .SingleOrDefaultAsync(e => e.EventId == id, ct);
        if (item is null) return NotFound();
        var categories = item.Categories.Select(c => new CategoryDto(c.CategoryId, c.EventId, c.CategoryName,
            c.DistanceKm, c.EntryFee, c.MaxParticipants, c.Enrolments.Count(x => x.Status == "Confirmed"),
            c.CategoryType)).ToList();
        return Ok(new EventDetailDto(item.EventId, item.EventName, item.Description, item.EventDate, item.StartTime,
            item.Location, item.RouteMapUrl, item.OrganiserId, item.Organiser.OrganisationName, categories,
            item.EventType, item.DistanceKm, item.BannerImageUrl));
    }

    [HttpPost]
    [Authorize(Roles = "Organiser")]
    public async Task<IActionResult> CreateEvent(EventWriteDto request, CancellationToken ct)
    {
        if (request.EventDate < DateOnly.FromDateTime(DateTime.Today))
            return BadRequest(new { message = "Event date cannot be in the past." });
        var organiserId = await db.Organisers.Where(o => o.UserId == CurrentUserId)
            .Select(o => (int?)o.OrganiserId).SingleOrDefaultAsync(ct);
        if (organiserId is null) return BadRequest(new { message = "Organiser profile not found." });
        var item = new Event { OrganiserId = organiserId.Value, EventName = request.EventName.Trim(),
            Description = request.Description, EventDate = request.EventDate, StartTime = request.StartTime,
            Location = request.Location.Trim(), RouteMapUrl = request.RouteMapUrl,
            EventType = request.EventType.Trim(), DistanceKm = request.DistanceKm };
        db.Events.Add(item);
        await db.SaveChangesAsync(ct);
        return CreatedAtAction(nameof(GetEvent), new { id = item.EventId }, ToSummary(item, null));
    }

    [HttpPut("{id:int}")]
    [Authorize(Roles = "Organiser")]
    public async Task<IActionResult> UpdateEvent(int id, EventWriteDto request, CancellationToken ct)
    {
        var item = await db.Events.Include(e => e.Organiser).SingleOrDefaultAsync(e => e.EventId == id, ct);
        if (item is null) return NotFound();
        if (item.Organiser.UserId != CurrentUserId) return Forbid();
        if (request.EventDate < DateOnly.FromDateTime(DateTime.Today))
            return BadRequest(new { message = "Event date cannot be in the past." });
        item.EventName = request.EventName.Trim(); item.Description = request.Description;
        item.EventDate = request.EventDate; item.StartTime = request.StartTime;
        item.Location = request.Location.Trim(); item.RouteMapUrl = request.RouteMapUrl;
        item.EventType = request.EventType.Trim(); item.DistanceKm = request.DistanceKm;
        await db.SaveChangesAsync(ct);
        return Ok(ToSummary(item, null));
    }

    [HttpDelete("{id:int}")]
    [Authorize(Roles = "Organiser")]
    public async Task<IActionResult> DeleteEvent(int id, CancellationToken ct)
    {
        var item = await db.Events.Include(e => e.Organiser).SingleOrDefaultAsync(e => e.EventId == id, ct);
        if (item is null) return NotFound();
        if (item.Organiser.UserId != CurrentUserId) return Forbid();
        db.Events.Remove(item);
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    private static EventSummaryDto ToSummary(Event e, string? organisationName) => new(e.EventId, e.EventName,
        e.Description, e.EventDate, e.StartTime, e.Location, e.RouteMapUrl, e.OrganiserId, organisationName,
        e.EventType, e.DistanceKm, e.BannerImageUrl);
}
