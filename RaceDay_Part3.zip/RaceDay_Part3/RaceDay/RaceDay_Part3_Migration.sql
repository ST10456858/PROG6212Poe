/* =========================================================
   RaceDay – Part 3 migration (run ONCE on an existing RaceDayDB)

   Adds the columns needed by the Part 3 MVC front end:
     Users.ProfilePictureUrl, Events.EventType / DistanceKm / BannerImageUrl,
     Categories.CategoryType, and the 'Pending' enrolment status.

   Safe to re-run: every change checks whether it already exists.
   If you are creating the database from scratch, just run
   RaceDay_Schema.sql instead (it already includes these changes).
   ========================================================= */
USE RaceDayDB;
GO

IF COL_LENGTH('dbo.Users', 'ProfilePictureUrl') IS NULL
    ALTER TABLE dbo.Users ADD ProfilePictureUrl NVARCHAR(500) NULL;
GO

IF COL_LENGTH('dbo.Events', 'EventType') IS NULL
    ALTER TABLE dbo.Events ADD EventType NVARCHAR(50) NOT NULL CONSTRAINT DF_Events_EventType DEFAULT ('Road Run');
GO
IF COL_LENGTH('dbo.Events', 'DistanceKm') IS NULL
    ALTER TABLE dbo.Events ADD DistanceKm DECIMAL(5,2) NULL;
GO
IF COL_LENGTH('dbo.Events', 'BannerImageUrl') IS NULL
    ALTER TABLE dbo.Events ADD BannerImageUrl NVARCHAR(500) NULL;
GO

IF COL_LENGTH('dbo.Categories', 'CategoryType') IS NULL
    ALTER TABLE dbo.Categories ADD CategoryType NVARCHAR(20) NOT NULL CONSTRAINT DF_Categories_CategoryType DEFAULT ('Distance');
GO
IF OBJECT_ID('dbo.CK_Categories_Type', 'C') IS NULL
    ALTER TABLE dbo.Categories ADD CONSTRAINT CK_Categories_Type CHECK (CategoryType IN ('Distance', 'Age'));
GO

IF OBJECT_ID('dbo.CK_Enrolments_Status', 'C') IS NOT NULL
    ALTER TABLE dbo.Enrolments DROP CONSTRAINT CK_Enrolments_Status;
GO
ALTER TABLE dbo.Enrolments ADD CONSTRAINT CK_Enrolments_Status CHECK (Status IN ('Confirmed', 'Pending', 'Cancelled'));
GO

/* Optional: give the seeded events sensible types/distances */
UPDATE dbo.Events SET EventType = 'Fun Run', DistanceKm = 10.00 WHERE EventName = 'Soweto Fun Run' AND DistanceKm IS NULL;
UPDATE dbo.Events SET EventType = 'Cycling', DistanceKm = 109.00 WHERE EventName = 'Cape Town Cycle Challenge' AND DistanceKm IS NULL;
UPDATE dbo.Events SET EventType = 'Road Run', DistanceKm = 42.20 WHERE EventName = 'Johannesburg City Marathon' AND DistanceKm IS NULL;
GO
