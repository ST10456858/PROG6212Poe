# RaceDay

RaceDay is an ASP.NET Core Web API targeting .NET 8, with SQL Server storage and an xUnit test project. The implementation follows the supplied `RaceDay_Schema.sql` and `API_Endpoint_Plan.md` while preserving the requested `RaceDay.API` and `RaceDay.Tests` project names.

## Requirements

- Visual Studio 2022 with the .NET 8 SDK, or the .NET 8 SDK and an IDE such as Visual Studio Code.
- SQL Server LocalDB (included with common Visual Studio workloads) or SQL Server.
- SQL Server Management Studio (SSMS) is recommended for running the supplied database script.

## 1. Create the database

1. Open `RaceDay_Schema.sql` in SSMS.
2. Connect to your local SQL Server instance.
3. Execute the script to create `RaceDayDB`, its tables, and sample data.

**Important:** the script drops and recreates the tables when rerun. Back up any data you need before running it again. I adjusted the `Enrolments` → `Participants` foreign key to `NO ACTION` because SQL Server rejects the original cascade setup as multiple cascade paths. This means a participant with enrolments cannot be deleted until those enrolments are removed; cancelling enrolments through the API is supported. The seeded password hashes (`HASHED_PASSWORD_1`, etc.) are placeholders, not valid login hashes. Create a real account through `POST /api/auth/register` to test authentication.

If your SQL Server instance is not LocalDB, update `ConnectionStrings:RaceDayDb` in `RaceDay.API/appsettings.json` to match your server. Do not commit real passwords or production secrets to source control.

## 2. Open and run

1. Open `RaceDay.sln` in Visual Studio.
2. Allow NuGet packages to restore.
3. Confirm the `RaceDay.API` connection string points to the database you created.
4. Set `RaceDay.API` as the startup project and run it.
5. In Development, Swagger opens at `https://localhost:7184/swagger` (or use the HTTP URL shown in `Properties/launchSettings.json`).

For the command line, from the `RaceDay` directory:

```powershell
dotnet restore RaceDay.sln
dotnet build RaceDay.sln
dotnet test RaceDay.sln
dotnet run --project RaceDay.API
```

## 3. JWT configuration

The included JWT key is a development-only placeholder. Before sharing or deploying the application, replace it with a securely generated random key of at least 32 bytes, preferably through user-secrets or environment variables rather than a committed settings file. The API issues JWTs valid for four hours. In Swagger, click **Authorize** and enter `Bearer YOUR_TOKEN` to call protected endpoints.

## Implemented endpoint groups

- Authentication: `POST /api/auth/register`, `POST /api/auth/login`
- User profile: `GET/PUT /api/users/me`
- Events: list, detail, create, update, delete under `/api/events`
- Categories: event category listing and organiser-owned category CRUD
- Enrolments: participant enrolment/cancellation, participant history, organiser event enrolment list
- Results: organiser capture/update, participant history, public event results

Ownership checks are performed by the API for event, category, enrolment, and result operations. The test project includes initial controller tests; run the test suite in your .NET environment to verify it there.

## Notes

- The supplied schema is the source of truth for table names and relationships.
- This project uses EF Core SQL Server and the existing SQL schema; it does not automatically create the database at startup.
- No frontend was supplied, so this package contains the API and tests only.

---

# Part 3 – RaceDay Web (ASP.NET Core MVC) + Azure Blob Storage + Docker

> **Demo video (unlisted YouTube):** _paste your link here before submitting_

Part 3 adds `RaceDay.Web`, an MVC front end that talks **only** to the Part 2 API (no database access, no business logic, no direct Azure access), and extends the API with Azure Blob Storage image uploads.

## What was added

| Area | Where |
|---|---|
| MVC app | `RaceDay.Web/` (Controllers, Views, Models, Services, Filters, `wwwroot`) |
| API client (all HTTP calls + error handling) | `RaceDay.Web/Services/RaceDayApiClient.cs` |
| Session auth + role guard | `Services/SessionUser.cs`, `Filters/SessionAuthorizeAttribute.cs` |
| Blob Storage in the API | `RaceDay.API/Services/BlobStorageService.cs`, `Controllers/ImagesController.cs` |
| New API fields/endpoints | Event `EventType`/`DistanceKm`/`BannerImageUrl`, Category `CategoryType`, User `ProfilePictureUrl`, `Pending` enrolment status, `GET api/events/mine`, `PUT api/enrolments/{id}/status`, `POST api/events/{id}/banner`, `POST api/users/me/profile-picture` |
| Database changes | `RaceDay_Schema.sql` (fresh DB) or `RaceDay_Part3_Migration.sql` (existing DB) |
| Docker | `RaceDay.Web/Dockerfile`, `RaceDay.API/Dockerfile`, `docker-compose.yml` |
| CI | `.github/workflows/raceday-ci.yml` (builds API, tests and MVC; builds the MVC image) |

## MVC structure (for the video)

- **Controllers** – thin: call `IRaceDayApi`, map results to view models, set flash messages. `Account`, `Home`, `Events` (public), `Organiser`, `Participant`, `Profile`.
- **Services** – `RaceDayApiClient` (typed `HttpClient`, adds the JWT, turns API errors into friendly messages), `SessionUser` (token, role, name kept in server-side session).
- **Filters** – `[SessionAuthorize(Roles = "...")]` redirects anonymous users to login and wrong-role users to *Access denied*.
- **Models** – `Models/Api` (API JSON shapes), `Models/ViewModels` (form/page models with validation).
- **Views** – Bootstrap 5 + RaceDay theme (`wwwroot/css/site.css`); role-specific navigation in `_Layout`.

## Run it

### Option A – everything in Docker (one command)

Needs Docker Desktop only. Starts SQL Server (schema auto-loaded), the Azurite blob emulator, the API and the MVC site:

```bash
docker compose up --build
```

Open **http://localhost:8080**. (The first start takes a minute while SQL Server initialises.) Register an Organiser and a Participant account to explore.

### Option B – MVC container only (API already running on your machine)

1. Run the API with the Docker-reachable profile (listens on `http://0.0.0.0:5184`):
   `dotnet run --project RaceDay.API --launch-profile "RaceDay.API (http, Docker-reachable)"`
2. Build and run the MVC container with a single command:

```bash
docker build -t raceday-web ./RaceDay.Web && docker run --rm -p 8080:8080 --add-host=host.docker.internal:host-gateway -e Api__BaseUrl=http://host.docker.internal:5184/ raceday-web
```

Open **http://localhost:8080**. The container behaves the same as running locally.

### Option C – run locally without Docker

1. Start the API (see Part 2 steps above).
2. `dotnet run --project RaceDay.Web` → https://localhost:7290
   (`Api:BaseUrl` in `RaceDay.Web/appsettings.json` defaults to `https://localhost:7184/`. If your dev certificate is untrusted, run `dotnet dev-certs https --trust`.)

## Azure Blob Storage setup

1. Create a Storage Account in Azure and allow **blob public read access** (images are served from the `raceday-images` container).
2. Store the connection string as a secret (never commit it):

```powershell
cd RaceDay.API
dotnet user-secrets init
dotnet user-secrets set "AzureBlob:ConnectionString" "<your connection string>"
```

3. Optional settings: `AzureBlob:ContainerName` (default `raceday-images`), `AzureBlob:PublicBaseUrl` (only for emulators).

For local testing without Azure, use Azurite (`docker run -p 10000:10000 mcr.microsoft.com/azure-storage/azurite azurite-blob --blobHost 0.0.0.0`), connection string `UseDevelopmentStorage=true`, and `AzureBlob:PublicBaseUrl = http://localhost:10000/devstoreaccount1`.

Uploads are validated in the API (JPG/PNG/WEBP by file signature, max 5 MB). If storage is not configured the user sees a friendly "image storage unavailable" message and the rest of the app keeps working.

## Database update

- New database: run `RaceDay_Schema.sql`.
- Existing Part 2 database: run `RaceDay_Part3_Migration.sql` once (re-runnable).
- Docker Option A loads the schema automatically.

## Features checklist

- **Auth:** register/login via API, JWT + role stored in session, distinct Organiser/Participant navigation, protected pages redirect to login, logout clears the session.
- **Organiser:** dashboard (event/enrolment totals, upcoming dates), event CRUD incl. type, distance and banner upload, categories (age or distance), enrolments (with status control), results entry/publishing.
- **Participant:** home with filters (location, date, type), event details, enrol with category, My Enrolments, My Results (e.g. "47th out of 312 finishers"), profile with picture upload.
- **UI:** colour-coded statuses (green Confirmed, amber Pending, grey Cancelled, red DNF), friendly validation and error pages (no raw errors).

## Notes

- Bootstrap, Bootstrap Icons, Google Fonts and jQuery validation load from CDNs, so the browser needs internet access.
- Compose passwords/keys are demo values only.
