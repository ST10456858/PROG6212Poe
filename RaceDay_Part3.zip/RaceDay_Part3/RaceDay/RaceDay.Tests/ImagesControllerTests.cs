using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using RaceDay.API.Controllers;
using RaceDay.API.Data;
using RaceDay.API.Models;
using RaceDay.API.Services;
using Xunit;

namespace RaceDay.Tests;

public class ImagesControllerTests
{
    private static RaceDayDbContext CreateDb()
    {
        var options = new DbContextOptionsBuilder<RaceDayDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
        return new RaceDayDbContext(options);
    }

    private static ImagesController CreateController(RaceDayDbContext db, IBlobStorageService blobs, int userId)
    {
        var controller = new ImagesController(db, blobs);
        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.NameIdentifier, userId.ToString()) }, "test");
        controller.ControllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext { User = new ClaimsPrincipal(identity) }
        };
        return controller;
    }

    private static async Task SeedEventAsync(RaceDayDbContext db)
    {
        var user = new User { UserId = 1, FullName = "Org", Email = "o@example.com", PasswordHash = "x", Role = "Organiser" };
        var organiser = new Organiser { OrganiserId = 1, UserId = 1, User = user };
        db.Users.Add(user);
        db.Organisers.Add(organiser);
        db.Events.Add(new Event { EventId = 1, OrganiserId = 1, Organiser = organiser, EventName = "Run", Location = "JHB",
            EventDate = DateOnly.FromDateTime(DateTime.Today.AddDays(5)) });
        await db.SaveChangesAsync();
    }

    private static IFormFile FileOf(byte[] bytes, string name = "banner.png")
    {
        var stream = new MemoryStream(bytes);
        return new FormFile(stream, 0, bytes.Length, "file", name);
    }

    [Fact]
    public async Task UploadBanner_ReturnsNotFound_WhenEventMissing()
    {
        using var db = CreateDb();
        var controller = CreateController(db, new Mock<IBlobStorageService>().Object, 1);
        var result = await controller.UploadBanner(99, null, CancellationToken.None);
        Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task UploadBanner_ReturnsForbid_WhenNotOwner()
    {
        using var db = CreateDb();
        await SeedEventAsync(db);
        var controller = CreateController(db, new Mock<IBlobStorageService>().Object, 2);
        var result = await controller.UploadBanner(1, null, CancellationToken.None);
        Assert.IsType<ForbidResult>(result);
    }

    [Fact]
    public async Task UploadBanner_ReturnsBadRequest_WhenFileIsNotAnImage()
    {
        using var db = CreateDb();
        await SeedEventAsync(db);
        var blobs = new Mock<IBlobStorageService>();
        var controller = CreateController(db, blobs.Object, 1);
        var notAnImage = FileOf("this is plain text, not an image"u8.ToArray(), "evil.png");
        var result = await controller.UploadBanner(1, notAnImage, CancellationToken.None);
        Assert.IsType<BadRequestObjectResult>(result);
        blobs.Verify(b => b.UploadImageAsync(It.IsAny<Stream>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task UploadBanner_StoresUrl_WhenImageIsValid()
    {
        using var db = CreateDb();
        await SeedEventAsync(db);
        var blobs = new Mock<IBlobStorageService>();
        blobs.Setup(b => b.UploadImageAsync(It.IsAny<Stream>(), "image/png", "banners", It.IsAny<CancellationToken>()))
            .ReturnsAsync("https://storage.example/raceday-images/banners/abc.png");
        var controller = CreateController(db, blobs.Object, 1);
        var png = new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0, 0, 0, 0 };

        var result = await controller.UploadBanner(1, FileOf(png), CancellationToken.None);

        Assert.IsType<OkObjectResult>(result);
        Assert.Equal("https://storage.example/raceday-images/banners/abc.png", (await db.Events.FindAsync(1))!.BannerImageUrl);
    }

    [Fact]
    public async Task UploadBanner_Returns503_WhenStorageUnavailable()
    {
        using var db = CreateDb();
        await SeedEventAsync(db);
        var blobs = new Mock<IBlobStorageService>();
        blobs.Setup(b => b.UploadImageAsync(It.IsAny<Stream>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new BlobStorageUnavailableException("down"));
        var controller = CreateController(db, blobs.Object, 1);
        var png = new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0, 0, 0, 0 };

        var result = await controller.UploadBanner(1, FileOf(png), CancellationToken.None);

        var status = Assert.IsType<ObjectResult>(result);
        Assert.Equal(503, status.StatusCode);
    }
}
