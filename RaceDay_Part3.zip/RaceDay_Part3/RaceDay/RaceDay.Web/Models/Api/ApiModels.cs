namespace RaceDay.Web.Models.Api;

// These classes mirror the JSON returned by the Part 2 API. They hold data only.

public class UserSummary
{
    public int UserId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
}

public class AuthResponse
{
    public string Token { get; set; } = string.Empty;
    public UserSummary User { get; set; } = new();
}

public class EventSummary
{
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateOnly EventDate { get; set; }
    public TimeOnly? StartTime { get; set; }
    public string Location { get; set; } = string.Empty;
    public string? RouteMapUrl { get; set; }
    public int OrganiserId { get; set; }
    public string? OrganisationName { get; set; }
    public string EventType { get; set; } = "Road Run";
    public decimal? DistanceKm { get; set; }
    public string? BannerImageUrl { get; set; }
}

public class EventDetail : EventSummary
{
    public List<CategoryInfo> Categories { get; set; } = new();
}

public class CategoryInfo
{
    public int CategoryId { get; set; }
    public int EventId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public string CategoryType { get; set; } = "Distance";
    public decimal DistanceKm { get; set; }
    public decimal EntryFee { get; set; }
    public int? MaxParticipants { get; set; }
    public int ConfirmedEnrolments { get; set; }
    public bool IsFull => MaxParticipants.HasValue && ConfirmedEnrolments >= MaxParticipants.Value;
}

public class OrganiserEvent
{
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateOnly EventDate { get; set; }
    public TimeOnly? StartTime { get; set; }
    public string Location { get; set; } = string.Empty;
    public string EventType { get; set; } = string.Empty;
    public decimal? DistanceKm { get; set; }
    public string? BannerImageUrl { get; set; }
    public int CategoryCount { get; set; }
    public int TotalEnrolments { get; set; }
}

public class EnrolmentInfo
{
    public int EnrolmentId { get; set; }
    public int ParticipantId { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public string ParticipantEmail { get; set; } = string.Empty;
    public int CategoryId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime EnrolmentDate { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateOnly? EventDate { get; set; }
}

public class ResultInfo
{
    public int ResultId { get; set; }
    public int EnrolmentId { get; set; }
    public TimeOnly? FinishTime { get; set; }
    public int? PositionOverall { get; set; }
    public int? PositionCategory { get; set; }
    public string Status { get; set; } = string.Empty;
    public int ParticipantId { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public string EventName { get; set; } = string.Empty;
    public string CategoryName { get; set; } = string.Empty;
    public int EventId { get; set; }
    public DateOnly? EventDate { get; set; }
    public int TotalFinishers { get; set; }
}

public class UserProfile
{
    public int UserId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string? OrganisationName { get; set; }
    public string? ContactNumber { get; set; }
    public DateOnly? DateOfBirth { get; set; }
    public string? EmergencyContact { get; set; }
    public string? ProfilePictureUrl { get; set; }
}
