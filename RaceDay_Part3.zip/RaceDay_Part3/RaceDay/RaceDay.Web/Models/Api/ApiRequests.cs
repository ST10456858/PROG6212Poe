namespace RaceDay.Web.Models.Api;

// JSON bodies sent to the Part 2 API.

public class LoginRequest
{
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}

public class RegisterRequest
{
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string Role { get; set; } = "Participant";
    public string? OrganisationName { get; set; }
    public string? ContactNumber { get; set; }
}

public class EventWriteRequest
{
    public string EventName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateOnly EventDate { get; set; }
    public TimeOnly? StartTime { get; set; }
    public string Location { get; set; } = string.Empty;
    public string? RouteMapUrl { get; set; }
    public string EventType { get; set; } = "Road Run";
    public decimal? DistanceKm { get; set; }
}

public class CategoryWriteRequest
{
    public string CategoryName { get; set; } = string.Empty;
    public string CategoryType { get; set; } = "Distance";
    public decimal DistanceKm { get; set; }
    public decimal EntryFee { get; set; }
    public int? MaxParticipants { get; set; }
}

public class ResultWriteRequest
{
    public TimeOnly? FinishTime { get; set; }
    public int? PositionOverall { get; set; }
    public int? PositionCategory { get; set; }
    public string Status { get; set; } = "Finished";
}

public class UpdateProfileRequest
{
    public string FullName { get; set; } = string.Empty;
    public string? OrganisationName { get; set; }
    public string? ContactNumber { get; set; }
    public DateOnly? DateOfBirth { get; set; }
    public string? EmergencyContact { get; set; }
}

public class EnrolmentStatusRequest
{
    public string Status { get; set; } = "Confirmed";
}
