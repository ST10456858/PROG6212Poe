using RaceDay.Web.Models.Api;

namespace RaceDay.Web.Models.ViewModels;

public class HomeViewModel
{
    public List<EventSummary> Events { get; set; } = new();
    public string? Location { get; set; }
    public DateOnly? From { get; set; }
    public string? EventType { get; set; }
    public string? LoadError { get; set; }
    public bool HasFilters => !string.IsNullOrWhiteSpace(Location) || From.HasValue || !string.IsNullOrWhiteSpace(EventType);
}

public class ErrorViewModel
{
    public int? Code { get; set; }
    public string Title { get; set; } = "Something went wrong";
    public string Message { get; set; } = "Please try again in a moment.";
}

public class EventDetailsViewModel
{
    public EventDetail Event { get; set; } = new();
    public List<ResultInfo> Results { get; set; } = new();
    public HashSet<int> EnrolledCategoryIds { get; set; } = new();
}
