using System.ComponentModel.DataAnnotations;
using RaceDay.Web.Models.Api;

namespace RaceDay.Web.Models.ViewModels;

public class OrganiserDashboardViewModel
{
    public List<OrganiserEvent> Events { get; set; } = new();
    public string? LoadError { get; set; }

    private static DateOnly Today => DateOnly.FromDateTime(DateTime.Today);

    public int TotalEvents => Events.Count;
    public int TotalEnrolments => Events.Sum(e => e.TotalEnrolments);
    public List<OrganiserEvent> Upcoming => Events.Where(e => e.EventDate >= Today).OrderBy(e => e.EventDate).ToList();
    public OrganiserEvent? NextEvent => Upcoming.FirstOrDefault();
    public int MaxEnrolments => Events.Count == 0 ? 0 : Events.Max(e => e.TotalEnrolments);
}

public class EventFormViewModel
{
    public int? EventId { get; set; }

    [Required(ErrorMessage = "Please enter an event name."), StringLength(150), Display(Name = "Event name")]
    public string EventName { get; set; } = string.Empty;

    [StringLength(1000), Display(Name = "Description")]
    public string? Description { get; set; }

    [Required(ErrorMessage = "Please choose the event date."), DataType(DataType.Date), Display(Name = "Event date")]
    public DateOnly? EventDate { get; set; }

    [DataType(DataType.Time), Display(Name = "Start time")]
    public TimeOnly? StartTime { get; set; }

    [Required(ErrorMessage = "Please enter the event location."), StringLength(200)]
    public string Location { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please choose an event type."), StringLength(50), Display(Name = "Event type")]
    public string EventType { get; set; } = "Road Run";

    [Required(ErrorMessage = "Please enter the event distance."), Range(0.01, 999.99, ErrorMessage = "Distance must be between 0.01 and 999.99 km."), Display(Name = "Distance (km)")]
    public decimal? DistanceKm { get; set; }

    [Url(ErrorMessage = "Please enter a valid web address (including https://)."), StringLength(255), Display(Name = "Route map link")]
    public string? RouteMapUrl { get; set; }

    [Display(Name = "Banner image")]
    public IFormFile? BannerImage { get; set; }

    public string? ExistingBannerUrl { get; set; }
}

public class CategoryFormViewModel
{
    public int? CategoryId { get; set; }
    public int EventId { get; set; }

    [Required(ErrorMessage = "Please enter a category name."), StringLength(100), Display(Name = "Category name")]
    public string CategoryName { get; set; } = string.Empty;

    [Required, RegularExpression("^(Distance|Age)$"), Display(Name = "Category type")]
    public string CategoryType { get; set; } = "Distance";

    [Required(ErrorMessage = "Please enter the distance."), Range(0.01, 999.99, ErrorMessage = "Distance must be between 0.01 and 999.99 km."), Display(Name = "Distance (km)")]
    public decimal? DistanceKm { get; set; }

    [Required(ErrorMessage = "Please enter the entry fee (0 for free)."), Range(0, 999999.99, ErrorMessage = "The entry fee must be 0 or more."), Display(Name = "Entry fee (R)")]
    public decimal? EntryFee { get; set; } = 0;

    [Range(1, int.MaxValue, ErrorMessage = "Maximum participants must be at least 1."), Display(Name = "Maximum participants")]
    public int? MaxParticipants { get; set; }
}

public class CategoriesPageViewModel
{
    public EventDetail Event { get; set; } = new();
    public CategoryFormViewModel Form { get; set; } = new();
}

public class EnrolmentsPageViewModel
{
    public EventDetail Event { get; set; } = new();
    public List<EnrolmentInfo> Enrolments { get; set; } = new();
}

public class ResultRow
{
    public int EnrolmentId { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public string CategoryName { get; set; } = string.Empty;
    public int? ResultId { get; set; }
    public TimeOnly? FinishTime { get; set; }
    public int? PositionOverall { get; set; }
    public int? PositionCategory { get; set; }
    public string Status { get; set; } = "Finished";
}

public class ResultsPageViewModel
{
    public EventDetail Event { get; set; } = new();
    public List<ResultRow> Rows { get; set; } = new();
}

public class ResultFormViewModel
{
    public int EventId { get; set; }
    public int EnrolmentId { get; set; }
    public int? ResultId { get; set; }
    public string? FinishTime { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Positions must be 1 or more.")]
    public int? PositionOverall { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Positions must be 1 or more.")]
    public int? PositionCategory { get; set; }

    [Required, RegularExpression("^(Finished|DNF|DNS)$")]
    public string Status { get; set; } = "Finished";
}
