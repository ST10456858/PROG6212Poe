using System.ComponentModel.DataAnnotations;

namespace RaceDay.Web.Models.ViewModels;

public class ProfileViewModel
{
    [Required(ErrorMessage = "Please enter your full name."), StringLength(150), Display(Name = "Full name")]
    public string FullName { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;

    [StringLength(150), Display(Name = "Organisation name")]
    public string? OrganisationName { get; set; }

    [StringLength(20), Display(Name = "Contact number")]
    public string? ContactNumber { get; set; }

    [DataType(DataType.Date), Display(Name = "Date of birth")]
    public DateOnly? DateOfBirth { get; set; }

    [StringLength(20), Display(Name = "Emergency contact number")]
    public string? EmergencyContact { get; set; }

    public string? ProfilePictureUrl { get; set; }
}
