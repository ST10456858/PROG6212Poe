using RaceDay.Web.Models.Api;

namespace RaceDay.Web.Models.ViewModels;

public class MyEnrolmentsViewModel
{
    public List<EnrolmentInfo> Enrolments { get; set; } = new();
    public string? LoadError { get; set; }
}

public class MyResultsViewModel
{
    public List<ResultInfo> Results { get; set; } = new();
    public string? LoadError { get; set; }
    public int RacesFinished => Results.Count(r => r.Status == "Finished");
    public int? BestPosition => Results.Where(r => r.Status == "Finished" && r.PositionOverall.HasValue)
        .Select(r => r.PositionOverall).Min();
}
