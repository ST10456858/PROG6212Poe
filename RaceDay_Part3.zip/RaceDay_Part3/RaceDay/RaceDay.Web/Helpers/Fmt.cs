using System.Globalization;

namespace RaceDay.Web.Helpers;

/// <summary>Presentation-only formatting helpers shared by the views.</summary>
public static class Fmt
{
    private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    public static readonly string[] EventTypes =
        { "Road Run", "Trail Run", "Fun Run", "Walk", "Cycling", "Triathlon", "Other" };

    public static readonly string[] EnrolmentStatuses = { "Confirmed", "Pending", "Cancelled" };
    public static readonly string[] ResultStatuses = { "Finished", "DNF", "DNS" };

    public static string Date(DateOnly? d) => d.HasValue ? d.Value.ToString("ddd, d MMM yyyy", Inv) : "–";
    public static string ShortDate(DateOnly? d) => d.HasValue ? d.Value.ToString("d MMM yyyy", Inv) : "–";
    public static string Month(DateOnly d) => d.ToString("MMM", Inv);
    public static string TimeInput(TimeOnly? t) => t.HasValue ? t.Value.ToString("HH:mm:ss", Inv) : string.Empty;
    public static string Time(TimeOnly? t) => t.HasValue ? t.Value.ToString("HH:mm", Inv) : "TBA";
    public static string FinishTime(TimeOnly? t) => t.HasValue ? t.Value.ToString("HH:mm:ss", Inv) : "–";
    public static string Km(decimal? km) => km.HasValue ? km.Value.ToString("0.##", Inv) + " km" : "–";
    public static string Money(decimal v) => v == 0 ? "Free" : "R" + v.ToString("N2", Inv);
    public static string DateTimeStamp(DateTime d) => d.ToString("d MMM yyyy, HH:mm", Inv);

    public static string Ordinal(int n)
    {
        var lastTwo = n % 100;
        if (lastTwo is >= 11 and <= 13) return n + "th";
        return (n % 10) switch
        {
            1 => n + "st",
            2 => n + "nd",
            3 => n + "rd",
            _ => n + "th"
        };
    }

    public static string Initials(string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return "?";
        var parts = name.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        return parts.Length == 1
            ? parts[0][..1].ToUpperInvariant()
            : (parts[0][..1] + parts[^1][..1]).ToUpperInvariant();
    }

    /// <summary>Colour-coded status: green = confirmed/finished, amber = pending, red = DNF, grey = cancelled/DNS.</summary>
    public static string StatusClass(string? status) => status?.ToLowerInvariant() switch
    {
        "confirmed" or "finished" => "status-confirmed",
        "pending" => "status-pending",
        "dnf" => "status-dnf",
        _ => "status-cancelled"
    };

    public static string TypeIcon(string? type) => type switch
    {
        "Road Run" => "lightning-charge-fill",
        "Trail Run" => "tree-fill",
        "Fun Run" => "emoji-smile-fill",
        "Walk" => "person-walking",
        "Cycling" => "bicycle",
        "Triathlon" => "trophy-fill",
        _ => "flag-fill"
    };

    public static string Pct(int value, int? max) =>
        max is > 0 ? Math.Min(100, value * 100 / max.Value).ToString(Inv) : "0";
}

/// <summary>Client-side friendly checks for uploaded images (the API re-validates everything).</summary>
public static class UploadRules
{
    public const long MaxBytes = 5 * 1024 * 1024;
    private static readonly string[] AllowedExtensions = { ".jpg", ".jpeg", ".png", ".webp" };

    public static string? Validate(IFormFile? file)
    {
        if (file is null || file.Length == 0) return null;
        if (file.Length > MaxBytes) return "The image must be 5 MB or smaller.";
        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        return AllowedExtensions.Contains(extension) ? null : "Only JPG, PNG or WEBP images are allowed.";
    }
}
