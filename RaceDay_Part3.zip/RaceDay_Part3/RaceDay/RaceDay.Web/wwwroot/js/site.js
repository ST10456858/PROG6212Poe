(function () {
    "use strict";

    // Confirmation prompts: <form data-confirm="Are you sure?">
    document.addEventListener("submit", function (e) {
        var form = e.target;
        var message = form.getAttribute && form.getAttribute("data-confirm");
        if (message && !window.confirm(message)) {
            e.preventDefault();
            return;
        }
        // Prevent double submits.
        var button = form.querySelector && form.querySelector("button[type=submit][data-busy]");
        if (button && !e.defaultPrevented) {
            window.setTimeout(function () {
                button.disabled = true;
                button.dataset.original = button.innerHTML;
                button.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>' + (button.getAttribute("data-busy") || "Working…");
            }, 0);
        }
    });

    // Live image preview: <input type="file" data-preview="#imgId">
    document.querySelectorAll("input[type=file][data-preview]").forEach(function (input) {
        input.addEventListener("change", function () {
            var target = document.querySelector(input.getAttribute("data-preview"));
            var file = input.files && input.files[0];
            if (!target || !file) { return; }
            var maxBytes = 5 * 1024 * 1024;
            if (file.size > maxBytes) {
                window.alert("That image is larger than 5 MB. Please choose a smaller one.");
                input.value = "";
                return;
            }
            target.src = URL.createObjectURL(file);
            target.classList.remove("d-none");
        });
    });

    // Auto-dismiss success alerts.
    window.setTimeout(function () {
        document.querySelectorAll(".rd-alert.alert-success").forEach(function (el) {
            if (window.bootstrap) { window.bootstrap.Alert.getOrCreateInstance(el).close(); }
        });
    }, 6000);
})();
