using RaceDay.Web.Models.Api;

namespace RaceDay.Web.Services;

/// <summary>
/// The only way the MVC app touches data. Every call goes to the Part 2 API —
/// no database access and no direct Azure access from this project.
/// </summary>
public interface IRaceDayApi
{
    // Authentication
    Task<ApiResult<AuthResponse>> LoginAsync(LoginRequest request);
    Task<ApiResult<AuthResponse>> RegisterAsync(RegisterRequest request);

    // Events
    Task<ApiResult<List<EventSummary>>> GetEventsAsync(string? location, DateOnly? from, string? eventType);
    Task<ApiResult<EventDetail>> GetEventAsync(int id);
    Task<ApiResult<List<OrganiserEvent>>> GetMyEventsAsync();
    Task<ApiResult<EventSummary>> CreateEventAsync(EventWriteRequest request);
    Task<ApiResult<EventSummary>> UpdateEventAsync(int id, EventWriteRequest request);
    Task<ApiResult> DeleteEventAsync(int id);
    Task<ApiResult> UploadBannerAsync(int eventId, IFormFile file);

    // Categories
    Task<ApiResult<CategoryInfo>> CreateCategoryAsync(int eventId, CategoryWriteRequest request);
    Task<ApiResult<CategoryInfo>> UpdateCategoryAsync(int categoryId, CategoryWriteRequest request);
    Task<ApiResult> DeleteCategoryAsync(int categoryId);

    // Enrolments
    Task<ApiResult> EnrolAsync(int categoryId);
    Task<ApiResult> CancelEnrolmentAsync(int enrolmentId);
    Task<ApiResult<List<EnrolmentInfo>>> GetMyEnrolmentsAsync();
    Task<ApiResult<List<EnrolmentInfo>>> GetEventEnrolmentsAsync(int eventId);
    Task<ApiResult> UpdateEnrolmentStatusAsync(int enrolmentId, string status);

    // Results
    Task<ApiResult<List<ResultInfo>>> GetEventResultsAsync(int eventId);
    Task<ApiResult<List<ResultInfo>>> GetMyResultsAsync();
    Task<ApiResult> SaveResultAsync(int enrolmentId, int? resultId, ResultWriteRequest request);

    // Profile
    Task<ApiResult<UserProfile>> GetProfileAsync();
    Task<ApiResult<UserProfile>> UpdateProfileAsync(UpdateProfileRequest request);
    Task<ApiResult> UploadProfilePictureAsync(IFormFile file);
}
