using RaceDay.Web.Models.Api;

namespace RaceDay.Web.Services;

/// <summary>The signed-in user, kept in server-side session state across all pages.</summary>
public interface ISessionUser
{
    bool IsAuthenticated { get; }
    bool IsOrganiser { get; }
    bool IsParticipant { get; }
    string? Token { get; }
    string? Role { get; }
    string? FullName { get; }
    int? UserId { get; }
    void SignIn(AuthResponse auth);
    void SetFullName(string fullName);
    void SignOut();
}
