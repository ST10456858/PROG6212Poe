using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using RaceDay.Web.Models.Api;

namespace RaceDay.Web.Services;

public class RaceDayApiClient : IRaceDayApi
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    private readonly HttpClient _http;
    private readonly ISessionUser _session;
    private readonly ILogger<RaceDayApiClient> _logger;

    public RaceDayApiClient(HttpClient http, ISessionUser session, ILogger<RaceDayApiClient> logger)
    {
        _http = http;
        _session = session;
        _logger = logger;
    }

    // ---------- Authentication ----------
    public Task<ApiResult<AuthResponse>> LoginAsync(LoginRequest request) =>
        SendAsync<AuthResponse>(HttpMethod.Post, "api/auth/login", request);

    public Task<ApiResult<AuthResponse>> RegisterAsync(RegisterRequest request) =>
        SendAsync<AuthResponse>(HttpMethod.Post, "api/auth/register", request);

    // ---------- Events ----------
    public Task<ApiResult<List<EventSummary>>> GetEventsAsync(string? location, DateOnly? from, string? eventType)
    {
        var query = new List<string>();
        if (!string.IsNullOrWhiteSpace(location)) query.Add("location=" + Uri.EscapeDataString(location.Trim()));
        if (from.HasValue) query.Add("from=" + from.Value.ToString("yyyy-MM-dd"));
        if (!string.IsNullOrWhiteSpace(eventType)) query.Add("eventType=" + Uri.EscapeDataString(eventType));
        var url = query.Count == 0 ? "api/events" : "api/events?" + string.Join("&", query);
        return SendAsync<List<EventSummary>>(HttpMethod.Get, url);
    }

    public Task<ApiResult<EventDetail>> GetEventAsync(int id) =>
        SendAsync<EventDetail>(HttpMethod.Get, $"api/events/{id}");

    public Task<ApiResult<List<OrganiserEvent>>> GetMyEventsAsync() =>
        SendAsync<List<OrganiserEvent>>(HttpMethod.Get, "api/events/mine");

    public Task<ApiResult<EventSummary>> CreateEventAsync(EventWriteRequest request) =>
        SendAsync<EventSummary>(HttpMethod.Post, "api/events", request);

    public Task<ApiResult<EventSummary>> UpdateEventAsync(int id, EventWriteRequest request) =>
        SendAsync<EventSummary>(HttpMethod.Put, $"api/events/{id}", request);

    public async Task<ApiResult> DeleteEventAsync(int id) =>
        await SendAsync<object>(HttpMethod.Delete, $"api/events/{id}");

    public Task<ApiResult> UploadBannerAsync(int eventId, IFormFile file) =>
        UploadAsync($"api/events/{eventId}/banner", file);

    // ---------- Categories ----------
    public Task<ApiResult<CategoryInfo>> CreateCategoryAsync(int eventId, CategoryWriteRequest request) =>
        SendAsync<CategoryInfo>(HttpMethod.Post, $"api/events/{eventId}/categories", request);

    public Task<ApiResult<CategoryInfo>> UpdateCategoryAsync(int categoryId, CategoryWriteRequest request) =>
        SendAsync<CategoryInfo>(HttpMethod.Put, $"api/categories/{categoryId}", request);

    public async Task<ApiResult> DeleteCategoryAsync(int categoryId) =>
        await SendAsync<object>(HttpMethod.Delete, $"api/categories/{categoryId}");

    // ---------- Enrolments ----------
    public async Task<ApiResult> EnrolAsync(int categoryId) =>
        await SendAsync<object>(HttpMethod.Post, $"api/categories/{categoryId}/enrolments");

    public async Task<ApiResult> CancelEnrolmentAsync(int enrolmentId) =>
        await SendAsync<object>(HttpMethod.Delete, $"api/enrolments/{enrolmentId}");

    public Task<ApiResult<List<EnrolmentInfo>>> GetMyEnrolmentsAsync() =>
        SendAsync<List<EnrolmentInfo>>(HttpMethod.Get, "api/users/me/enrolments");

    public Task<ApiResult<List<EnrolmentInfo>>> GetEventEnrolmentsAsync(int eventId) =>
        SendAsync<List<EnrolmentInfo>>(HttpMethod.Get, $"api/events/{eventId}/enrolments");

    public async Task<ApiResult> UpdateEnrolmentStatusAsync(int enrolmentId, string status) =>
        await SendAsync<object>(HttpMethod.Put, $"api/enrolments/{enrolmentId}/status",
            new EnrolmentStatusRequest { Status = status });

    // ---------- Results ----------
    public Task<ApiResult<List<ResultInfo>>> GetEventResultsAsync(int eventId) =>
        SendAsync<List<ResultInfo>>(HttpMethod.Get, $"api/events/{eventId}/results");

    public Task<ApiResult<List<ResultInfo>>> GetMyResultsAsync() =>
        SendAsync<List<ResultInfo>>(HttpMethod.Get, "api/users/me/results");

    public async Task<ApiResult> SaveResultAsync(int enrolmentId, int? resultId, ResultWriteRequest request) =>
        resultId.HasValue
            ? await SendAsync<object>(HttpMethod.Put, $"api/results/{resultId.Value}", request)
            : await SendAsync<object>(HttpMethod.Post, $"api/enrolments/{enrolmentId}/results", request);

    // ---------- Profile ----------
    public Task<ApiResult<UserProfile>> GetProfileAsync() =>
        SendAsync<UserProfile>(HttpMethod.Get, "api/users/me");

    public Task<ApiResult<UserProfile>> UpdateProfileAsync(UpdateProfileRequest request) =>
        SendAsync<UserProfile>(HttpMethod.Put, "api/users/me", request);

    public Task<ApiResult> UploadProfilePictureAsync(IFormFile file) =>
        UploadAsync("api/users/me/profile-picture", file);

    // ---------- Plumbing ----------
    private async Task<ApiResult> UploadAsync(string url, IFormFile file)
    {
        using var content = new MultipartFormDataContent();
        await using var stream = file.OpenReadStream();
        using var fileContent = new StreamContent(stream);
        fileContent.Headers.ContentType = MediaTypeHeaderValue.TryParse(file.ContentType, out var mediaType)
            ? mediaType
            : new MediaTypeHeaderValue("application/octet-stream");
        content.Add(fileContent, "file", file.FileName);
        return await SendAsync<object>(HttpMethod.Post, url, content: content);
    }

    private async Task<ApiResult<T>> SendAsync<T>(HttpMethod method, string url, object? body = null,
        HttpContent? content = null)
    {
        using var request = new HttpRequestMessage(method, url);
        if (!string.IsNullOrEmpty(_session.Token))
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _session.Token);
        if (content is not null)
            request.Content = content;
        else if (body is not null)
            request.Content = JsonContent.Create(body, body.GetType(), options: Json);

        try
        {
            using var response = await _http.SendAsync(request);
            var status = (int)response.StatusCode;

            if (!response.IsSuccessStatusCode)
                return new ApiResult<T> { StatusCode = status, Error = await ReadErrorAsync(response) };

            if (response.StatusCode == HttpStatusCode.NoContent || response.Content.Headers.ContentLength == 0)
                return new ApiResult<T> { Success = true, StatusCode = status };

            var data = await response.Content.ReadFromJsonAsync<T>(Json);
            return new ApiResult<T> { Success = true, StatusCode = status, Data = data };
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "RaceDay API request failed: {Method} {Url}", method, url);
            return Fail<T>(503, "RaceDay is temporarily unavailable. Please try again in a moment.");
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogError(ex, "RaceDay API request timed out: {Method} {Url}", method, url);
            return Fail<T>(504, "RaceDay took too long to respond. Please try again.");
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "Unexpected API response: {Method} {Url}", method, url);
            return Fail<T>(502, "RaceDay returned an unexpected response. Please try again.");
        }
    }

    private static ApiResult<T> Fail<T>(int status, string message) =>
        new() { StatusCode = status, Error = message };

    /// <summary>Turns an API error body into a short, user-friendly sentence — never raw JSON or stack traces.</summary>
    private static async Task<string> ReadErrorAsync(HttpResponseMessage response)
    {
        try
        {
            var text = await response.Content.ReadAsStringAsync();
            if (!string.IsNullOrWhiteSpace(text))
            {
                using var doc = JsonDocument.Parse(text);
                var root = doc.RootElement;
                if (root.ValueKind == JsonValueKind.Object)
                {
                    if (root.TryGetProperty("errors", out var errors) && errors.ValueKind == JsonValueKind.Object)
                    {
                        var messages = errors.EnumerateObject()
                            .Where(p => p.Value.ValueKind == JsonValueKind.Array)
                            .SelectMany(p => p.Value.EnumerateArray())
                            .Where(v => v.ValueKind == JsonValueKind.String)
                            .Select(v => v.GetString())
                            .Where(IsReadable)
                            .Distinct()
                            .ToList();
                        if (messages.Count > 0) return string.Join(" ", messages);
                    }

                    if (root.TryGetProperty("message", out var message) && message.ValueKind == JsonValueKind.String
                        && IsReadable(message.GetString()))
                        return message.GetString()!;
                }
            }
        }
        catch (JsonException)
        {
            // Not JSON — fall through to the generic message.
        }

        return FriendlyMessage((int)response.StatusCode);
    }

    private static bool IsReadable(string? message) =>
        !string.IsNullOrWhiteSpace(message)
        && !message.Contains("JSON", StringComparison.OrdinalIgnoreCase)
        && !message.Contains("Path:", StringComparison.OrdinalIgnoreCase);

    private static string FriendlyMessage(int status) => status switch
    {
        400 => "Some of the information provided isn't valid. Please check it and try again.",
        401 => "Please log in to continue.",
        403 => "You don't have permission to do that.",
        404 => "We couldn't find what you were looking for.",
        409 => "That conflicts with something that already exists.",
        413 => "That file is too large.",
        >= 500 => "Something went wrong on our side. Please try again shortly.",
        _ => "Something went wrong. Please try again."
    };
}
