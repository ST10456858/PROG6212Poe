using RaceDay.Web.Models.Api;

namespace RaceDay.Web.Services;

public class SessionUser(IHttpContextAccessor accessor) : ISessionUser
{
    private const string TokenKey = "rd.token";
    private const string RoleKey = "rd.role";
    private const string NameKey = "rd.name";
    private const string IdKey = "rd.id";

    private ISession? Session => accessor.HttpContext?.Session;

    public string? Token => Session?.GetString(TokenKey);
    public string? Role => Session?.GetString(RoleKey);
    public string? FullName => Session?.GetString(NameKey);
    public int? UserId => Session?.GetInt32(IdKey);

    public bool IsAuthenticated => !string.IsNullOrEmpty(Token);
    public bool IsOrganiser => IsAuthenticated && string.Equals(Role, "Organiser", StringComparison.OrdinalIgnoreCase);
    public bool IsParticipant => IsAuthenticated && string.Equals(Role, "Participant", StringComparison.OrdinalIgnoreCase);

    public void SignIn(AuthResponse auth)
    {
        var session = Session ?? throw new InvalidOperationException("Session is not available.");
        session.Clear();
        session.SetString(TokenKey, auth.Token);
        session.SetString(RoleKey, auth.User.Role);
        session.SetString(NameKey, auth.User.FullName);
        session.SetInt32(IdKey, auth.User.UserId);
    }

    public void SetFullName(string fullName) => Session?.SetString(NameKey, fullName);

    public void SignOut() => Session?.Clear();
}
