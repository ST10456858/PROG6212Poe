using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models.Api;
using RaceDay.Web.Models.ViewModels;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class AccountController(IRaceDayApi api, ISessionUser session) : AppController
{
    [HttpGet]
    public IActionResult Login(string? returnUrl = null, string? reason = null)
    {
        if (session.IsAuthenticated) return RedirectToHome(session);
        if (reason == "login") Flash("Warning", "Please log in to continue.");
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var result = await api.LoginAsync(new LoginRequest { Email = model.Email.Trim(), Password = model.Password });
        if (!result.Success || result.Data is null)
        {
            ModelState.AddModelError(string.Empty,
                result.IsUnauthorized ? "Invalid email or password." : result.Error);
            return View(model);
        }

        session.SignIn(result.Data);
        Flash("Success", $"Welcome back, {result.Data.User.FullName}!");

        if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            return LocalRedirect(model.ReturnUrl);
        return RedirectToHome(session);
    }

    [HttpGet]
    public IActionResult Register()
    {
        if (session.IsAuthenticated) return RedirectToHome(session);
        return View(new RegisterViewModel());
    }

    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var result = await api.RegisterAsync(new RegisterRequest
        {
            FullName = model.FullName.Trim(),
            Email = model.Email.Trim(),
            Password = model.Password,
            Role = model.Role,
            OrganisationName = model.Role == "Organiser" ? model.OrganisationName?.Trim() : null,
            ContactNumber = string.IsNullOrWhiteSpace(model.ContactNumber) ? null : model.ContactNumber.Trim()
        });

        if (!result.Success || result.Data is null)
        {
            ModelState.AddModelError(string.Empty, result.Error);
            return View(model);
        }

        session.SignIn(result.Data);
        Flash("Success", $"Welcome to RaceDay, {result.Data.User.FullName}! Your account is ready.");
        return RedirectToHome(session);
    }

    [HttpPost]
    public IActionResult Logout()
    {
        session.SignOut();
        Flash("Success", "You have been logged out.");
        return RedirectToAction("Index", "Home");
    }

    [HttpGet]
    public IActionResult AccessDenied() => View();
}
