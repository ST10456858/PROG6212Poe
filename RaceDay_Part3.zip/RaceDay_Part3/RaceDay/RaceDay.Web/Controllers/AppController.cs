using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public abstract class AppController : Controller
{
    protected void Flash(string kind, string message) => TempData[kind] = message;

    /// <summary>
    /// Handles the two API failures that need a redirect rather than an inline message:
    /// an expired/invalid token (back to login) and a forbidden call (access denied).
    /// Returns null when the result needs no special handling.
    /// </summary>
    protected IActionResult? HandleFailure(ApiResult result)
    {
        if (result.IsUnauthorized)
        {
            HttpContext.RequestServices.GetRequiredService<ISessionUser>().SignOut();
            Flash("Warning", "Your session has expired. Please log in again.");
            return RedirectToAction("Login", "Account");
        }

        if (result.IsForbidden)
        {
            Flash("Error", "You don't have permission to do that.");
            return RedirectToAction("AccessDenied", "Account");
        }

        return null;
    }

    protected IActionResult RedirectToHome(ISessionUser session) =>
        session.IsOrganiser
            ? RedirectToAction("Dashboard", "Organiser")
            : RedirectToAction("Index", "Home");
}
