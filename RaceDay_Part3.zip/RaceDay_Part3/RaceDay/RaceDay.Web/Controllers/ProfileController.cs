using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Helpers;
using RaceDay.Web.Models.Api;
using RaceDay.Web.Models.ViewModels;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[SessionAuthorize]
public class ProfileController(IRaceDayApi api, ISessionUser session) : AppController
{
    private const long MaxUploadBytes = 6 * 1024 * 1024;

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var result = await api.GetProfileAsync();
        var fail = HandleFailure(result);
        if (fail is not null) return fail;
        if (!result.Success || result.Data is null)
        {
            Flash("Error", result.Error);
            return RedirectToHome(session);
        }
        return View(ToViewModel(result.Data));
    }

    [HttpPost]
    public async Task<IActionResult> UpdateDetails(ProfileViewModel model)
    {
        if (!ModelState.IsValid) return View("Index", model);

        var result = await api.UpdateProfileAsync(new UpdateProfileRequest
        {
            FullName = model.FullName.Trim(),
            OrganisationName = model.OrganisationName,
            ContactNumber = model.ContactNumber,
            DateOfBirth = model.DateOfBirth,
            EmergencyContact = model.EmergencyContact
        });
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        if (!result.Success || result.Data is null)
        {
            ModelState.AddModelError(string.Empty, result.Error);
            return View("Index", model);
        }

        session.SetFullName(result.Data.FullName);
        Flash("Success", "Your profile has been updated.");
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [RequestSizeLimit(MaxUploadBytes)]
    public async Task<IActionResult> UploadPicture(IFormFile? picture)
    {
        if (picture is null || picture.Length == 0)
        {
            Flash("Error", "Please choose an image to upload.");
            return RedirectToAction(nameof(Index));
        }

        var problem = UploadRules.Validate(picture);
        if (problem is not null)
        {
            Flash("Error", problem);
            return RedirectToAction(nameof(Index));
        }

        var result = await api.UploadProfilePictureAsync(picture);
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        if (result.Success) Flash("Success", "Your profile picture has been updated.");
        else Flash("Error", result.Error);
        return RedirectToAction(nameof(Index));
    }

    private static ProfileViewModel ToViewModel(UserProfile p) => new()
    {
        FullName = p.FullName,
        Email = p.Email,
        Role = p.Role,
        OrganisationName = p.OrganisationName,
        ContactNumber = p.ContactNumber,
        DateOfBirth = p.DateOfBirth,
        EmergencyContact = p.EmergencyContact,
        ProfilePictureUrl = p.ProfilePictureUrl
    };
}
