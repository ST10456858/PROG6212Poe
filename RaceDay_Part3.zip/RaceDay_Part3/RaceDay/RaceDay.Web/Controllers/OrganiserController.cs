using System.Globalization;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Helpers;
using RaceDay.Web.Models.Api;
using RaceDay.Web.Models.ViewModels;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[SessionAuthorize(Roles = "Organiser")]
public class OrganiserController(IRaceDayApi api) : AppController
{
    private const long MaxUploadBytes = 6 * 1024 * 1024;
    private static readonly Regex FinishTimePattern = new(@"^\d{1,2}:[0-5]\d:[0-5]\d$", RegexOptions.Compiled);

    // ---------------------------------------------------------------- Dashboard
    [HttpGet]
    public async Task<IActionResult> Dashboard()
    {
        var result = await api.GetMyEventsAsync();
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        return View(new OrganiserDashboardViewModel
        {
            Events = result.Data ?? new(),
            LoadError = result.Success ? null : result.Error
        });
    }

    // ---------------------------------------------------------------- Events
    [HttpGet]
    public async Task<IActionResult> Events()
    {
        var result = await api.GetMyEventsAsync();
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        return View(new OrganiserDashboardViewModel
        {
            Events = (result.Data ?? new()).OrderByDescending(e => e.EventDate).ToList(),
            LoadError = result.Success ? null : result.Error
        });
    }

    [HttpGet]
    public IActionResult CreateEvent() =>
        View("EventForm", new EventFormViewModel { EventDate = DateOnly.FromDateTime(DateTime.Today.AddDays(30)) });

    [HttpPost]
    [RequestSizeLimit(MaxUploadBytes)]
    public async Task<IActionResult> CreateEvent(EventFormViewModel model)
    {
        ValidateBanner(model);
        if (!ModelState.IsValid) return View("EventForm", model);

        var result = await api.CreateEventAsync(ToRequest(model));
        var fail = HandleFailure(result);
        if (fail is not null) return fail;
        if (!result.Success || result.Data is null)
        {
            ModelState.AddModelError(string.Empty, result.Error);
            return View("EventForm", model);
        }

        var eventId = result.Data.EventId;
        if (model.BannerImage is { Length: > 0 })
        {
            var upload = await api.UploadBannerAsync(eventId, model.BannerImage);
            if (!upload.Success)
            {
                Flash("Warning", $"Event created, but the banner couldn't be uploaded: {upload.Error} You can add it by editing the event.");
                return RedirectToAction(nameof(Categories), new { eventId });
            }
        }

        Flash("Success", "Event created. Now add the categories people can enter.");
        return RedirectToAction(nameof(Categories), new { eventId });
    }

    [HttpGet]
    public async Task<IActionResult> EditEvent(int id)
    {
        var (evt, redirect) = await LoadOwnedEventAsync(id);
        if (redirect is not null) return redirect;

        return View("EventForm", new EventFormViewModel
        {
            EventId = evt!.EventId,
            EventName = evt.EventName,
            Description = evt.Description,
            EventDate = evt.EventDate,
            StartTime = evt.StartTime,
            Location = evt.Location,
            EventType = evt.EventType,
            DistanceKm = evt.DistanceKm,
            RouteMapUrl = evt.RouteMapUrl,
            ExistingBannerUrl = evt.BannerImageUrl
        });
    }

    [HttpPost]
    [RequestSizeLimit(MaxUploadBytes)]
    public async Task<IActionResult> EditEvent(int id, EventFormViewModel model)
    {
        model.EventId = id;
        ValidateBanner(model);
        if (!ModelState.IsValid) return View("EventForm", model);

        var result = await api.UpdateEventAsync(id, ToRequest(model));
        var fail = HandleFailure(result);
        if (fail is not null) return fail;
        if (!result.Success)
        {
            ModelState.AddModelError(string.Empty, result.Error);
            return View("EventForm", model);
        }

        if (model.BannerImage is { Length: > 0 })
        {
            var upload = await api.UploadBannerAsync(id, model.BannerImage);
            if (!upload.Success)
            {
                Flash("Warning", $"Event updated, but the banner couldn't be uploaded: {upload.Error}");
                return RedirectToAction(nameof(Events));
            }
        }

        Flash("Success", "Event updated.");
        return RedirectToAction(nameof(Events));
    }

    [HttpPost]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        var result = await api.DeleteEventAsync(id);
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        if (result.Success) Flash("Success", "Event deleted.");
        else Flash("Error", result.Error);
        return RedirectToAction(nameof(Events));
    }

    // ---------------------------------------------------------------- Categories
    [HttpGet]
    public async Task<IActionResult> Categories(int eventId, int? editId)
    {
        var (evt, redirect) = await LoadOwnedEventAsync(eventId);
        if (redirect is not null) return redirect;

        var form = new CategoryFormViewModel { EventId = eventId, DistanceKm = evt!.DistanceKm };
        if (editId.HasValue)
        {
            var existing = evt.Categories.FirstOrDefault(c => c.CategoryId == editId.Value);
            if (existing is not null)
                form = new CategoryFormViewModel
                {
                    CategoryId = existing.CategoryId,
                    EventId = eventId,
                    CategoryName = existing.CategoryName,
                    CategoryType = existing.CategoryType,
                    DistanceKm = existing.DistanceKm,
                    EntryFee = existing.EntryFee,
                    MaxParticipants = existing.MaxParticipants
                };
        }

        return View(new CategoriesPageViewModel { Event = evt, Form = form });
    }

    [HttpPost]
    public async Task<IActionResult> SaveCategory([Bind(Prefix = "Form")] CategoryFormViewModel model)
    {
        if (!ModelState.IsValid) return await ShowCategoriesWithErrorAsync(model);

        var request = new CategoryWriteRequest
        {
            CategoryName = model.CategoryName.Trim(),
            CategoryType = model.CategoryType,
            DistanceKm = model.DistanceKm ?? 0,
            EntryFee = model.EntryFee ?? 0,
            MaxParticipants = model.MaxParticipants
        };

        var result = model.CategoryId.HasValue
            ? (ApiResult)await api.UpdateCategoryAsync(model.CategoryId.Value, request)
            : await api.CreateCategoryAsync(model.EventId, request);
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        if (!result.Success)
        {
            ModelState.AddModelError(string.Empty, result.Error);
            return await ShowCategoriesWithErrorAsync(model);
        }

        Flash("Success", model.CategoryId.HasValue ? "Category updated." : "Category added.");
        return RedirectToAction(nameof(Categories), new { eventId = model.EventId });
    }

    [HttpPost]
    public async Task<IActionResult> DeleteCategory(int id, int eventId)
    {
        var result = await api.DeleteCategoryAsync(id);
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        if (result.Success) Flash("Success", "Category deleted.");
        else Flash("Error", result.Error);
        return RedirectToAction(nameof(Categories), new { eventId });
    }

    // ---------------------------------------------------------------- Enrolments
    [HttpGet]
    public async Task<IActionResult> Enrolments(int eventId)
    {
        var (evt, redirect) = await LoadOwnedEventAsync(eventId);
        if (redirect is not null) return redirect;

        var enrolments = await api.GetEventEnrolmentsAsync(eventId);
        var fail = HandleFailure(enrolments);
        if (fail is not null) return fail;
        if (!enrolments.Success) Flash("Error", enrolments.Error);

        return View(new EnrolmentsPageViewModel
        {
            Event = evt!,
            Enrolments = (enrolments.Data ?? new()).OrderBy(e => e.CategoryName).ThenBy(e => e.ParticipantName).ToList()
        });
    }

    [HttpPost]
    public async Task<IActionResult> UpdateEnrolmentStatus(int enrolmentId, int eventId, string status)
    {
        if (!Fmt.EnrolmentStatuses.Contains(status))
        {
            Flash("Error", "Please choose a valid status.");
            return RedirectToAction(nameof(Enrolments), new { eventId });
        }

        var result = await api.UpdateEnrolmentStatusAsync(enrolmentId, status);
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        if (result.Success) Flash("Success", $"Enrolment marked as {status}.");
        else Flash("Error", result.Error);
        return RedirectToAction(nameof(Enrolments), new { eventId });
    }

    // ---------------------------------------------------------------- Results
    [HttpGet]
    public async Task<IActionResult> Results(int eventId)
    {
        var (evt, redirect) = await LoadOwnedEventAsync(eventId);
        if (redirect is not null) return redirect;

        var enrolments = await api.GetEventEnrolmentsAsync(eventId);
        var fail = HandleFailure(enrolments);
        if (fail is not null) return fail;
        var results = await api.GetEventResultsAsync(eventId);

        if (!enrolments.Success) Flash("Error", enrolments.Error);
        var byEnrolment = (results.Data ?? new()).ToDictionary(r => r.EnrolmentId);

        var rows = (enrolments.Data ?? new())
            .Where(e => e.Status == "Confirmed")
            .Select(e =>
            {
                byEnrolment.TryGetValue(e.EnrolmentId, out var r);
                return new ResultRow
                {
                    EnrolmentId = e.EnrolmentId,
                    ParticipantName = e.ParticipantName,
                    CategoryName = e.CategoryName,
                    ResultId = r?.ResultId,
                    FinishTime = r?.FinishTime,
                    PositionOverall = r?.PositionOverall,
                    PositionCategory = r?.PositionCategory,
                    Status = r?.Status ?? "Finished"
                };
            })
            .OrderBy(r => r.PositionOverall ?? int.MaxValue)
            .ThenBy(r => r.ParticipantName)
            .ToList();

        return View(new ResultsPageViewModel { Event = evt!, Rows = rows });
    }

    [HttpPost]
    public async Task<IActionResult> SaveResult(ResultFormViewModel model)
    {
        TimeOnly? finishTime = null;
        var timeText = model.FinishTime?.Trim();
        if (!string.IsNullOrEmpty(timeText))
        {
            if (!FinishTimePattern.IsMatch(timeText)
                || !TimeOnly.TryParse(timeText, CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsed))
                ModelState.AddModelError(nameof(model.FinishTime), "Enter the finish time as hh:mm:ss, for example 01:45:32.");
            else
                finishTime = parsed;
        }

        if (model.Status == "Finished")
        {
            if (finishTime is null && ModelState.IsValid)
                ModelState.AddModelError(nameof(model.FinishTime), "Enter a finish time for participants who finished.");
            if (model.PositionOverall is null && ModelState.IsValid)
                ModelState.AddModelError(nameof(model.PositionOverall), "Enter the overall finishing position.");
        }

        if (!ModelState.IsValid)
        {
            var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage)
                .FirstOrDefault(m => !string.IsNullOrWhiteSpace(m)) ?? "Please check the result and try again.";
            Flash("Error", message);
            return RedirectToAction(nameof(Results), new { eventId = model.EventId });
        }

        var result = await api.SaveResultAsync(model.EnrolmentId, model.ResultId, new ResultWriteRequest
        {
            FinishTime = finishTime,
            PositionOverall = model.PositionOverall,
            PositionCategory = model.PositionCategory,
            Status = model.Status
        });
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        if (result.Success) Flash("Success", "Result saved and published to the participant.");
        else Flash("Error", result.Error);
        return RedirectToAction(nameof(Results), new { eventId = model.EventId });
    }

    // ---------------------------------------------------------------- Helpers
    /// <summary>Loads an event only if it belongs to the signed-in organiser (otherwise returns a redirect).</summary>
    private async Task<(EventDetail? Event, IActionResult? Redirect)> LoadOwnedEventAsync(int eventId)
    {
        var mine = await api.GetMyEventsAsync();
        var fail = HandleFailure(mine);
        if (fail is not null) return (null, fail);
        if (!mine.Success)
        {
            Flash("Error", mine.Error);
            return (null, RedirectToAction(nameof(Dashboard)));
        }

        if (mine.Data is null || mine.Data.All(e => e.EventId != eventId))
        {
            Flash("Error", "That event couldn't be found among your events.");
            return (null, RedirectToAction(nameof(Events)));
        }

        var detail = await api.GetEventAsync(eventId);
        if (!detail.Success || detail.Data is null)
        {
            Flash("Error", detail.Error);
            return (null, RedirectToAction(nameof(Events)));
        }

        return (detail.Data, null);
    }

    private async Task<IActionResult> ShowCategoriesWithErrorAsync(CategoryFormViewModel model)
    {
        var (evt, redirect) = await LoadOwnedEventAsync(model.EventId);
        if (redirect is not null) return redirect;
        return View("Categories", new CategoriesPageViewModel { Event = evt!, Form = model });
    }

    private void ValidateBanner(EventFormViewModel model)
    {
        var problem = UploadRules.Validate(model.BannerImage);
        if (problem is not null) ModelState.AddModelError(nameof(model.BannerImage), problem);
    }

    private static EventWriteRequest ToRequest(EventFormViewModel model) => new()
    {
        EventName = model.EventName.Trim(),
        Description = string.IsNullOrWhiteSpace(model.Description) ? null : model.Description.Trim(),
        EventDate = model.EventDate ?? default,
        StartTime = model.StartTime,
        Location = model.Location.Trim(),
        RouteMapUrl = string.IsNullOrWhiteSpace(model.RouteMapUrl) ? null : model.RouteMapUrl.Trim(),
        EventType = model.EventType,
        DistanceKm = model.DistanceKm
    };
}
