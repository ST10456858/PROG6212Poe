using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models.ViewModels;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

[SessionAuthorize(Roles = "Participant")]
public class ParticipantController(IRaceDayApi api) : AppController
{
    [HttpGet]
    public async Task<IActionResult> MyEnrolments()
    {
        var result = await api.GetMyEnrolmentsAsync();
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        return View(new MyEnrolmentsViewModel
        {
            Enrolments = (result.Data ?? new()).OrderByDescending(e => e.EventDate).ThenBy(e => e.EventName).ToList(),
            LoadError = result.Success ? null : result.Error
        });
    }

    [HttpPost]
    public async Task<IActionResult> Enrol(int categoryId, int eventId)
    {
        var result = await api.EnrolAsync(categoryId);
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        if (result.Success) Flash("Success", "You're in! Your enrolment has been recorded.");
        else Flash("Error", result.Error);
        return RedirectToAction("Details", "Events", new { id = eventId });
    }

    [HttpPost]
    public async Task<IActionResult> CancelEnrolment(int id)
    {
        var result = await api.CancelEnrolmentAsync(id);
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        if (result.Success) Flash("Success", "Your enrolment has been cancelled.");
        else Flash("Error", result.Error);
        return RedirectToAction(nameof(MyEnrolments));
    }

    [HttpGet]
    public async Task<IActionResult> MyResults()
    {
        var result = await api.GetMyResultsAsync();
        var fail = HandleFailure(result);
        if (fail is not null) return fail;

        return View(new MyResultsViewModel
        {
            Results = (result.Data ?? new()).OrderByDescending(r => r.EventDate).ToList(),
            LoadError = result.Success ? null : result.Error
        });
    }
}
