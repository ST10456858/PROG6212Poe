using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models.ViewModels;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

/// <summary>Public event detail page (visible to everyone; enrol buttons depend on the signed-in role).</summary>
public class EventsController(IRaceDayApi api, ISessionUser session) : AppController
{
    [HttpGet]
    public async Task<IActionResult> Details(int id)
    {
        var evt = await api.GetEventAsync(id);
        if (evt.IsNotFound) return NotFound();
        if (!evt.Success || evt.Data is null)
        {
            Flash("Error", evt.Error);
            return RedirectToAction("Index", "Home");
        }

        var model = new EventDetailsViewModel { Event = evt.Data };

        var results = await api.GetEventResultsAsync(id);
        if (results.Success && results.Data is not null)
            model.Results = results.Data.OrderBy(r => r.PositionOverall ?? int.MaxValue).ToList();

        if (session.IsParticipant)
        {
            var mine = await api.GetMyEnrolmentsAsync();
            if (mine.IsUnauthorized) return HandleFailure(mine)!;
            if (mine.Success && mine.Data is not null)
                model.EnrolledCategoryIds = mine.Data.Where(e => e.Status != "Cancelled")
                    .Select(e => e.CategoryId).ToHashSet();
        }

        return View(model);
    }
}
