using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models.ViewModels;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class HomeController(IRaceDayApi api) : AppController
{
    [HttpGet]
    public async Task<IActionResult> Index(string? location, DateOnly? from, string? eventType)
    {
        var result = await api.GetEventsAsync(location, from, eventType);
        return View(new HomeViewModel
        {
            Location = location,
            From = from,
            EventType = eventType,
            Events = result.Data ?? new(),
            LoadError = result.Success ? null : result.Error
        });
    }

    [IgnoreAntiforgeryToken]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error(int? code)
    {
        var model = code switch
        {
            404 => new ErrorViewModel { Code = 404, Title = "Page not found", Message = "We couldn't find the page you were looking for." },
            403 => new ErrorViewModel { Code = 403, Title = "Access denied", Message = "You don't have permission to view that page." },
            400 or 413 => new ErrorViewModel { Code = code, Title = "That didn't work", Message = "We couldn't process that request. Please check what you entered and try again." },
            _ => new ErrorViewModel { Code = code, Title = "Something went wrong", Message = "An unexpected problem occurred. Please try again in a moment." }
        };
        Response.StatusCode = code is >= 400 and <= 599 ? code.Value : 500;
        return View(model);
    }
}
