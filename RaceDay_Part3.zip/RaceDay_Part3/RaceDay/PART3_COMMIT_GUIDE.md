# Part 3 – suggested commit sequence (20+ meaningful commits)

Create a branch, then commit in logical steps (run each `git add` + `git commit`):

```bash
git checkout -b part3-mvc-frontend
```

| # | Message | `git add` |
|---|---|---|
| 1 | Add Part 3 schema changes and migration script | `RaceDay_Schema.sql RaceDay_Part3_Migration.sql` |
| 2 | Add event type, distance and banner fields to models/DbContext | `RaceDay.API/Models RaceDay.API/Data` |
| 3 | Update DTOs for new event/category/user fields | `RaceDay.API/Dtos` |
| 4 | Add organiser "my events" endpoint and event filters | `RaceDay.API/Controllers/EventsController.cs` |
| 5 | Support category type and enrolment status endpoint | `RaceDay.API/Controllers/CategoriesController.cs RaceDay.API/Controllers/EnrolmentsController.cs` |
| 6 | Add finisher totals and dates to results/enrolments | `RaceDay.API/Controllers/ResultsController.cs RaceDay.API/Controllers/UsersController.cs` |
| 7 | Add Azure Blob Storage service | `RaceDay.API/Services RaceDay.API/RaceDay.API.csproj RaceDay.API/appsettings.json` |
| 8 | Add image upload endpoints with validation | `RaceDay.API/Controllers/ImagesController.cs RaceDay.API/Program.cs` |
| 9 | Add image upload unit tests | `RaceDay.Tests` |
| 10 | Scaffold RaceDay.Web MVC project | `RaceDay.Web/RaceDay.Web.csproj RaceDay.Web/Program.cs RaceDay.Web/appsettings.json RaceDay.Web/Properties RaceDay.sln` |
| 11 | Add API client and session services | `RaceDay.Web/Services RaceDay.Web/Models/Api` |
| 12 | Add session authorization filter | `RaceDay.Web/Filters` |
| 13 | Add layout, theme and role-based navigation | `RaceDay.Web/Views/Shared RaceDay.Web/Views/_ViewImports.cshtml RaceDay.Web/Views/_ViewStart.cshtml RaceDay.Web/wwwroot RaceDay.Web/Helpers` |
| 14 | Add register/login/logout | `RaceDay.Web/Controllers/AccountController.cs RaceDay.Web/Controllers/AppController.cs RaceDay.Web/Views/Account RaceDay.Web/Models/ViewModels/AccountViewModels.cs` |
| 15 | Add home page with event filters and details page | `RaceDay.Web/Controllers/HomeController.cs RaceDay.Web/Controllers/EventsController.cs RaceDay.Web/Views/Home RaceDay.Web/Views/Events RaceDay.Web/Models/ViewModels/HomeViewModels.cs` |
| 16 | Add organiser dashboard and event management | `RaceDay.Web/Controllers/OrganiserController.cs RaceDay.Web/Views/Organiser/Dashboard.cshtml RaceDay.Web/Views/Organiser/Events.cshtml RaceDay.Web/Views/Organiser/EventForm.cshtml` |
| 17 | Add category and enrolment management | `RaceDay.Web/Views/Organiser/Categories.cshtml RaceDay.Web/Views/Organiser/Enrolments.cshtml` |
| 18 | Add results entry page | `RaceDay.Web/Views/Organiser/Results.cshtml RaceDay.Web/Models/ViewModels/OrganiserViewModels.cs` |
| 19 | Add participant enrolments and results pages | `RaceDay.Web/Controllers/ParticipantController.cs RaceDay.Web/Views/Participant RaceDay.Web/Models/ViewModels/ParticipantViewModels.cs` |
| 20 | Add profile page with picture upload | `RaceDay.Web/Controllers/ProfileController.cs RaceDay.Web/Views/Profile RaceDay.Web/Models/ViewModels/ProfileViewModel.cs` |
| 21 | Add Dockerfiles and docker-compose | `RaceDay.Web/Dockerfile RaceDay.Web/.dockerignore RaceDay.API/Dockerfile RaceDay.API/.dockerignore docker-compose.yml` |
| 22 | Update GitHub Actions to build the MVC project | `.github` |
| 23 | Document Part 3 in README | `README.md PART3_COMMIT_GUIDE.md .gitignore` |

Fix-ups you make while testing (build errors, CSS tweaks) are extra real commits — that's expected.
If your repo root is the folder *above* `RaceDay/`, move `.github/` to the repo root (the workflow finds `RaceDay.sln` automatically).
